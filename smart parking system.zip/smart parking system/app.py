from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect("parking.db")
    conn.row_factory = sqlite3.Row
    return conn

def create_database():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS slots (
            id INTEGER PRIMARY KEY,
            status TEXT NOT NULL
        )
    """)

    count = conn.execute("SELECT COUNT(*) FROM slots").fetchone()[0]

    if count == 0:
        for i in range(1, 11):
            conn.execute(
                "INSERT INTO slots (id, status) VALUES (?, ?)",
                (i, "Available")
            )

    conn.commit()
    conn.close()


@app.route("/")
def home():
    conn = get_db()
    slots = conn.execute("SELECT * FROM slots").fetchall()
    conn.close()

    return render_template("index.html", slots=slots)


@app.route("/book/<int:slot_id>", methods=["POST"])
def book(slot_id):
    conn = get_db()

    conn.execute(
        "UPDATE slots SET status = 'Reserved' WHERE id = ? AND status = 'Available'",
        (slot_id,)
    )

    conn.commit()
    conn.close()

    return redirect("/")


@app.route("/cancel/<int:slot_id>", methods=["POST"])
def cancel(slot_id):
    conn = get_db()

    conn.execute(
        "UPDATE slots SET status = 'Available' WHERE id = ?",
        (slot_id,)
    )

    conn.commit()
    conn.close()

    return redirect("/")


if __name__ == "__main__":
    create_database()
    app.run(debug=True)